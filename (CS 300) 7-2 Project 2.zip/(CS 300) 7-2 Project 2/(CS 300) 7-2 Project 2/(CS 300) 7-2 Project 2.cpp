// (CS 300) 7-2 Project 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <algorithm>
#include <climits>
#include <iostream>
#include <string>
#include <vector>
#include "CSVparser.hpp"
#include <fstream>
#include <sstream>
#include <iostream>


using namespace std;


vector<vector<string>> parseCSV(const string& filename) {
    vector<vector<string>> data;
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return data;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;
        string cell;

        while (getline(ss, cell, ',')) {
            row.push_back(cell);
        }

        data.push_back(row);
    }

    file.close();
    return data;
}


// Structure to hold course information
struct Course {
    int courseId;
    string courseNum;  // New variable to store the current value of courseId
    string title;
    vector<string> prereqs;
};

// Hash Table class definition
class HashTable {
private:
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        Node() : key(UINT_MAX), next(nullptr) {}
        Node(const Course& acourse) : key(UINT_MAX), next(nullptr), course(acourse) {}
        Node(const Course& acourse, unsigned int aKey) : key(aKey), next(nullptr), course(acourse) {}
    };

    vector<Node> nodes;
    unsigned int tableSize;

    unsigned int hash(int key);

public:
    HashTable(unsigned int size = 179);
    ~HashTable();
    void insertCourse(const Course& course);
    void printAllCourses() const;
    void removeCourse(const int& courseId);
    Course searchCourse(const int& courseId);
};

// HashTable methods implementation

HashTable::HashTable(unsigned int size) : tableSize(size) {
    nodes.resize(tableSize);
}

HashTable::~HashTable() {
    for (Node& node : nodes) {
        Node* current = node.next;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
}

unsigned int HashTable::hash(int key) {
    return key % tableSize;
}

void HashTable::insertCourse(const Course& course) {
    unsigned int key = hash(course.courseId);
    Node& node = nodes[key];

    if (node.key == UINT_MAX) {
        node.key = key;
        node.course = course;
        node.next = nullptr;
    }
    else {
        Node* newNode = new Node(course, key);
        Node* current = node.next;

        if (current == nullptr) {
            node.next = newNode;
        }
        else {
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }
}

void HashTable::printAllCourses() const {
    for (const Node& node : nodes) {
        if (node.key != UINT_MAX) {
            const Node* current = &node;
            while (current != nullptr) {
                cout << "Key: " << current->key << "\n";
                cout << "Course ID: " << current->course.courseId << "\n";
                cout << "Course Num: " << current->course.courseNum << "\n";
                cout << "Title: " << current->course.title << "\n";
                for (string i : current->course.prereqs) {
                    cout << "Prerequisites: " << i << ", ";
                }
                cout << endl;
                current = current->next;
            }
        }
    }
}

void HashTable::removeCourse(const int& courseId) {
    unsigned int key = hash(courseId);
    Node* currentNode = &nodes[key];
    Node* previousNode = nullptr;

    while (currentNode != nullptr && currentNode->course.courseId != courseId) {
        previousNode = currentNode;
        currentNode = currentNode->next;
    }

    if (currentNode == nullptr) {
        return;
    }

    if (previousNode == nullptr) {
        if (currentNode->next == nullptr) {
            nodes[key] = Node();
        }
        else {
            nodes[key] = *(currentNode->next);
        }
    }
    else {
        previousNode->next = currentNode->next;
    }

    delete currentNode;
}

Course HashTable::searchCourse(const int& courseId) {
    unsigned int key = hash(courseId);
    Node& node = nodes[key];

    if (node.key != UINT_MAX) {
        Node* current = &node;
        while (current != nullptr) {
            if (current->course.courseId == courseId) {
                return current->course;
            }
            current = current->next;
        }
    }

    return Course();
}

// Static method used for testing

void displayCourse(const Course& course) {
    cout << course.courseId << ": " << "|" << course.courseNum << ": " << course.title << " | ";
    for (string i : course.prereqs) {
        cout << "Prerequisites: " << i << ", ";
    }
    cout << endl;
}

void loadCourses(HashTable* hashTable) {
    cout << "Loading CSV file " << "Input.csv" << endl;

    vector<vector<string>> data = parseCSV("Input.csv");
    if (data.empty()) {
        cout << "Failed to parse CSV file." << endl;
        return;
    }

    int i = 0;
    for (const auto& row : data) {
        if (row.size() < 2) {
            cout << "Invalid row: " << endl;
            continue;
        }

        Course course;
        course.courseId = i;
        course.courseNum = row[0];  
        course.title = row[1];


        for (size_t i = 2; i < row.size(); i++) {
            course.prereqs.push_back(row[i]);
        }

        hashTable->insertCourse(course);
        i++;
    }

    hashTable->printAllCourses();
}


/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}


int main()
{
    clock_t ticks;
    HashTable* courseTable = new HashTable();
    int choice = 0;

    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "1. Load Courses" << endl;
        cout << "2. Display All Courses" << endl;
        cout << "3. Find Course" << endl;
        cout << "9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            clock_t startTicks = clock();
            // Assuming the loadCourses function takes the CSV path and the HashTable as arguments
            // and loads the courses into the HashTable.
            loadCourses(courseTable);
            ticks = clock() - startTicks;
            cout << "Clock ticks: " << ticks << endl;
            cout << "Time taken: " << static_cast<double>(ticks) / CLOCKS_PER_SEC << " seconds" << endl;
            break;
        }
        case 2: {
            // Assuming the displayAllCourses function is defined in the HashTable class
            courseTable->printAllCourses();
            break;
        }
        case 3: {
            string courseId;

            cout << "Enter course number: ";
            cin >> courseId;

            ticks = clock();
            Course course = courseTable->searchCourse(stoi(courseId));
            ticks = clock() - ticks;
            if (course.courseId != NULL) {
                displayCourse(course);
            }
            else {
                cout << "Course not found." << endl;
            }
            cout << "Clock ticks: " << ticks << endl;
            cout << "Time taken: " << static_cast<double>(ticks) / CLOCKS_PER_SEC << " seconds" << endl;
            break;
        }
        }
    }

    cout << "Goodbye." << endl;
    delete courseTable;
    return 0;
}
