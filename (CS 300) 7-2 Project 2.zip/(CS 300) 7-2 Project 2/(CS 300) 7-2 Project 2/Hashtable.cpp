#include <algorithm>
#include <climits>
#include <iostream>
#include <string>
#include <vector>
#include "CSVparser.hpp"

using namespace std;

// Structure to hold course information
struct Course {
    string courseId;
    string title;
    vector<string> prereqs;
};

// Hash Table class definition
class HashTable {
private:
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        Node() : key(UINT_MAX), next(nullptr) {}
        Node(const Course& acourse) : key(UINT_MAX), next(nullptr), course(acourse) {}
        Node(const Course& acourse, unsigned int aKey) : key(aKey), next(nullptr), course(acourse) {}
    };

    vector<Node> nodes;
    unsigned int tableSize;

    unsigned int hash(int key);

public:
    HashTable(unsigned int size = 179);
    ~HashTable();
    void insertCourse(const Course& course);
    void printAllCourses() const;
    void removeCourse(const string& courseId);
    Course searchCourse(const string& courseId);
};

// HashTable methods implementation

HashTable::HashTable(unsigned int size) : tableSize(size) {
    nodes.resize(tableSize);
}

HashTable::~HashTable() {
    for (Node& node : nodes) {
        Node* current = node.next;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
}

unsigned int HashTable::hash(int key) {
    return key % tableSize;
}

void HashTable::insertCourse(const Course& course) {
    unsigned int key = hash(stoi(course.courseId));
    Node& node = nodes[key];

    if (node.key == UINT_MAX) {
        node.key = key;
        node.course = course;
        node.next = nullptr;
    }
    else {
        Node* newNode = new Node(course, key);
        Node* current = node.next;

        if (current == nullptr) {
            node.next = newNode;
        }
        else {
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }
}

void HashTable::printAllCourses() const {
    for (const Node& node : nodes) {
        if (node.key != UINT_MAX) {
            const Node* current = &node;
            while (current != nullptr) {
                cout << "Key: " << current->key << "\n";
                cout << "Course ID: " << current->course.courseId << "\n";
                cout << "Title: " << current->course.title << "\n";
                for (string i : current->course.prereqs) {
                    cout << "Prerequisites: " << i << ", ";
                }
                cout << endl;
                current = current->next;
            }
        }
    }
}

void HashTable::removeCourse(const string& courseId) {
    unsigned int key = hash(stoi(courseId));
    Node* currentNode = &nodes[key];
    Node* previousNode = nullptr;

    while (currentNode != nullptr && currentNode->course.courseId != courseId) {
        previousNode = currentNode;
        currentNode = currentNode->next;
    }

    if (currentNode == nullptr) {
        return;
    }

    if (previousNode == nullptr) {
        if (currentNode->next == nullptr) {
            nodes[key] = Node();
        }
        else {
            nodes[key] = *(currentNode->next);
        }
    }
    else {
        previousNode->next = currentNode->next;
    }

    delete currentNode;
}

Course HashTable::searchCourse(const string& courseId) {
    unsigned int key = hash(stoi(courseId));
    Node& node = nodes[key];

    if (node.key != UINT_MAX) {
        Node* current = &node;
        while (current != nullptr) {
            if (current->course.courseId == courseId) {
                return current->course;
            }
            current = current->next;
        }
    }

    return Course();
}

// Static method used for testing

void displayCourse(const Course& course) {
    cout << course.courseId << ": " << course.title << " | ";
    for (string i : course.prereqs) {
        cout << "Prerequisites: " << i << ", ";
    }
    cout << endl;
}

void loadcourses(HashTable* hashTable) {
    cout << "Loading CSV file " << "Input.csv" << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser("Input.csv");

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of courses
            Course course;
            course.courseId = file[i][0];
            course.title = file[i][1];
            unsigned int j = 2;
            while (file[i][j] != "") {
                course.prereqs.insert(course.prereqs.begin(), file[i][j]);
                j++;
            }

            //cout << "Item: " << course.title << ", Fund: " << course.fund << ", Amount: " << course.amount << endl;

            // push this course to the end
            hashTable->insertCourse(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

